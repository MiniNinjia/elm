import { Component } from '@angular/core';
import { NavController,ModalController } from 'ionic-angular';
import {ShopPage} from '../shop/shop'
<<<<<<< HEAD
import {HomePage} from "../home/home";
import {OrderdetailPage} from "../orderdetail/orderdetail";
=======
>>>>>>> origin/master

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {

  constructor(public navCtrl: NavController,
              public modalCtrl: ModalController,) {

  }
<<<<<<< HEAD
  disMiss(){
    this.navCtrl.push(HomePage)
    this.viewCtrl.dismiss();
  }
  jump(){
    let modelPage = this.modalCtrl.create(OrderdetailPage);
    modelPage.present()
  }

=======
>>>>>>> origin/master
}
