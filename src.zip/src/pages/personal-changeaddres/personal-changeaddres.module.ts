import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PersonalChangeaddresPage } from './personal-changeaddres';

@NgModule({
  declarations: [
    PersonalChangeaddresPage,
  ],
  imports: [
    IonicPageModule.forChild(PersonalChangeaddresPage),
  ],
})
export class PersonalChangeaddresPageModule {}
